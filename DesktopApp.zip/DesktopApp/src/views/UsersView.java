package views;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class UsersView extends JPanel {
    private JTable table;
    private DefaultTableModel model;
    private JTextField fnameField, lnameField, usernameField, passwordField;
    private JComboBox<String> roleBox;
    private JButton addBtn, updateBtn, deleteBtn;

    private int selectedUserId = -1;

    public UsersView() {
        setLayout(null);

        // ===== TABLE =====
        model = new DefaultTableModel(new String[]{"ID", "First Name", "Last Name", "Username", "Password", "Role"}, 0);
        table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(20, 250, 750, 230); // Table size
        loadUsers();
        add(scrollPane);

        // ===== FORM PANEL =====
        JLabel fnameLabel = new JLabel("First Name:");
        fnameLabel.setBounds(30, 20, 100, 25);
        add(fnameLabel);

        fnameField = new JTextField();
        fnameField.setBounds(130, 20, 200, 25);
        add(fnameField);

        JLabel lnameLabel = new JLabel("Last Name:");
        lnameLabel.setBounds(400, 20, 100, 25);
        add(lnameLabel);

        lnameField = new JTextField();
        lnameField.setBounds(500, 20, 200, 25);
        add(lnameField);

        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setBounds(30, 60, 100, 25);
        add(usernameLabel);

        usernameField = new JTextField();
        usernameField.setBounds(130, 60, 200, 25);
        add(usernameField);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(400, 60, 100, 25);
        add(passwordLabel);

        passwordField = new JTextField();
        passwordField.setBounds(500, 60, 200, 25);
        add(passwordField);

        JLabel roleLabel = new JLabel("Role:");
        roleLabel.setBounds(30, 100, 100, 25);
        add(roleLabel);

        roleBox = new JComboBox<>(new String[]{"Admin", "User"});
        roleBox.setBounds(130, 100, 200, 25);
        add(roleBox);

        // ===== BUTTONS =====
        addBtn = new JButton("Add");
        addBtn.setBounds(130, 150, 100, 30);
        add(addBtn);

        updateBtn = new JButton("Update");
        updateBtn.setBounds(250, 150, 100, 30);
        add(updateBtn);

        deleteBtn = new JButton("Delete");
        deleteBtn.setBounds(370, 150, 100, 30);
        add(deleteBtn);

        // ===== EVENTS =====
        addBtn.addActionListener(e -> insertUser());
        updateBtn.addActionListener(e -> updateUser());
        deleteBtn.addActionListener(e -> deleteUser());
        table.getSelectionModel().addListSelectionListener(e -> fillFormFromTable());
    }

    private void fillFormFromTable() {
        int row = table.getSelectedRow();
        if (row >= 0) {
            selectedUserId = Integer.parseInt(model.getValueAt(row, 0).toString());
            fnameField.setText(model.getValueAt(row, 1).toString());
            lnameField.setText(model.getValueAt(row, 2).toString());
            usernameField.setText(model.getValueAt(row, 3).toString());
            passwordField.setText(model.getValueAt(row, 4).toString());
            roleBox.setSelectedItem(model.getValueAt(row, 5).toString());
        }
    }

    private void loadUsers() {
        model.setRowCount(0);
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/oop", "root", "");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM users")) {
            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("user_id"),
                    rs.getString("fname"),
                    rs.getString("lname"),
                    rs.getString("username"),
                    rs.getString("password"),
                    rs.getString("role")
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading users: " + e.getMessage());
        }
    }

    private void insertUser() {
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/oop", "root", "")) {
            String sql = "INSERT INTO users (fname, lname, username, password, role) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, fnameField.getText());
            stmt.setString(2, lnameField.getText());
            stmt.setString(3, usernameField.getText());
            stmt.setString(4, passwordField.getText());
            stmt.setString(5, roleBox.getSelectedItem().toString());
            stmt.executeUpdate();
            loadUsers();
            clearForm();
            JOptionPane.showMessageDialog(this, "User added!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Insert error: " + e.getMessage());
        }
    }

    private void updateUser() {
        if (selectedUserId == -1) {
            JOptionPane.showMessageDialog(this, "Select a user first!");
            return;
        }
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/oop", "root", "")) {
            String sql = "UPDATE users SET fname=?, lname=?, username=?, password=?, role=? WHERE user_id=?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, fnameField.getText());
            stmt.setString(2, lnameField.getText());
            stmt.setString(3, usernameField.getText());
            stmt.setString(4, passwordField.getText());
            stmt.setString(5, roleBox.getSelectedItem().toString());
            stmt.setInt(6, selectedUserId);
            stmt.executeUpdate();
            loadUsers();
            clearForm();
            JOptionPane.showMessageDialog(this, "User updated!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Update error: " + e.getMessage());
        }
    }

    private void deleteUser() {
        if (selectedUserId == -1) {
            JOptionPane.showMessageDialog(this, "Select a user to delete!");
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this user?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/oop", "root", "")) {
                String sql = "DELETE FROM users WHERE user_id=?";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setInt(1, selectedUserId);
                stmt.executeUpdate();
                loadUsers();
                clearForm();
                JOptionPane.showMessageDialog(this, "User deleted!");
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Delete error: " + e.getMessage());
            }
        }
    }

    private void clearForm() {
        selectedUserId = -1;
        fnameField.setText("");
        lnameField.setText("");
        usernameField.setText("");
        passwordField.setText("");
        roleBox.setSelectedIndex(0);
        table.clearSelection();
    }
}
