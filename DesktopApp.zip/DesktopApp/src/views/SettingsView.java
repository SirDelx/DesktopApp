package views;

import javax.swing.*;

public class SettingsView extends JPanel {
    public SettingsView() {
        add(new JLabel("Settings Panel"));
    }
}
