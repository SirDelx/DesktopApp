package views;

import org.knowm.xchart.*;
import org.knowm.xchart.style.Styler.*;
import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.util.*;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import org.knowm.xchart.CategoryChart;
import org.knowm.xchart.CategoryChartBuilder;
import org.knowm.xchart.style.Styler.LegendPosition;




public class DashboardView extends JPanel {
    public DashboardView(String role) {
        setLayout(new BorderLayout());

        JLabel title = new JLabel(role + " Dashboard - User Role Chart");
        title.setFont(new Font("Segoe UI", Font.BOLD, 16));
        title.setHorizontalAlignment(SwingConstants.CENTER);
        add(title, BorderLayout.NORTH);

        Map<String, Integer> userCounts = getUserCounts();

        List<String> roles = new ArrayList<>(userCounts.keySet());
        List<Integer> counts = new ArrayList<>();
        for (String r : roles) counts.add(userCounts.get(r));

        CategoryChart chart = new CategoryChartBuilder()
            .width(800)
            .height(400)
            .title("Users by Role")
            .xAxisTitle("Role")
            .yAxisTitle("Count")
            .build();

        // ONLY this works if chart is CategoryChart
  


        chart.getStyler().setLegendPosition(LegendPosition.InsideNE);
      
        chart.getStyler().setChartBackgroundColor(Color.WHITE);
        chart.addSeries("Users", roles, counts);

        XChartPanel<CategoryChart> chartPanel = new XChartPanel<>(chart);
        add(chartPanel, BorderLayout.CENTER);
    }

    private Map<String, Integer> getUserCounts() {
        Map<String, Integer> map = new HashMap<>();
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/oop", "root", "");
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT role, COUNT(*) as count FROM users GROUP BY role")) {
            while (rs.next()) {
                map.put(rs.getString("role"), rs.getInt("count"));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "DB Error: " + e.getMessage());
        }
        return map;
    }
}
