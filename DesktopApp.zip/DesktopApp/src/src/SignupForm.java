package src;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class SignupForm extends JFrame {
    JTextField fnameField, lnameField, usernameField;
    JPasswordField passwordField;
    JButton signupBtn, goToLoginBtn;

    public SignupForm() {
        setTitle("Signup Form");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 500);
        setLocationRelativeTo(null); // Center the frame

        // MAIN PANEL
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(null); // Allow absolute positioning
        add(mainPanel);

        // LEFT SIDE - IMAGE
        JLabel imageLabel = new JLabel();
        imageLabel.setIcon(new ImageIcon("../../images/signup.jpg"));
        imageLabel.setBounds(0, 0, 400, 500); // Image section
        mainPanel.add(imageLabel);

        // RIGHT SIDE - FORM PANEL
        JPanel formPanel = new JPanel(null);
        formPanel.setBounds(400, 0, 400, 500); // Right half of window
        mainPanel.add(formPanel);

        JLabel title = new JLabel("Create Your Account");
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setBounds(80, 30, 250, 30);
        formPanel.add(title);

        // Labels and Fields
        JLabel fnameLabel = new JLabel("First Name");
        fnameLabel.setBounds(50, 80, 100, 25);
        formPanel.add(fnameLabel);

        fnameField = new JTextField();
        fnameField.setBounds(50, 105, 300, 30);
        formPanel.add(fnameField);

        JLabel lnameLabel = new JLabel("Last Name");
        lnameLabel.setBounds(50, 145, 100, 25);
        formPanel.add(lnameLabel);

        lnameField = new JTextField();
        lnameField.setBounds(50, 170, 300, 30);
        formPanel.add(lnameField);

        JLabel usernameLabel = new JLabel("Username");
        usernameLabel.setBounds(50, 210, 100, 25);
        formPanel.add(usernameLabel);

        usernameField = new JTextField();
        usernameField.setBounds(50, 235, 300, 30);
        formPanel.add(usernameField);

        JLabel passwordLabel = new JLabel("Password");
        passwordLabel.setBounds(50, 275, 100, 25);
        formPanel.add(passwordLabel);

        passwordField = new JPasswordField();
        passwordField.setBounds(50, 300, 300, 30);
        formPanel.add(passwordField);

        // Buttons
        signupBtn = new JButton("Sign Up");
        signupBtn.setBounds(50, 350, 300, 30);
        formPanel.add(signupBtn);

        goToLoginBtn = new JButton("Go to Login");
        goToLoginBtn.setBounds(50, 390, 300, 30);
        formPanel.add(goToLoginBtn);

        // ACTIONS
        signupBtn.addActionListener(e -> insertUser());
        goToLoginBtn.addActionListener(e -> {
            dispose();
            new LoginForm();
        });

        setVisible(true);
    }

    void insertUser() {
        try {
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/oop", "root", "");
            String sql = "INSERT INTO users(fname, lname, username, password, role) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, fnameField.getText());
            stmt.setString(2, lnameField.getText());
            stmt.setString(3, usernameField.getText());
            stmt.setString(4, new String(passwordField.getPassword()));
            stmt.setString(5, "User"); // Default role
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Registered Successfully!");
            conn.close();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(new com.formdev.flatlaf.FlatLightLaf());
        } catch (Exception e) {
            System.err.println("FlatLaf initialization failed.");
        }
        SwingUtilities.invokeLater(SignupForm::new);
    }
}
