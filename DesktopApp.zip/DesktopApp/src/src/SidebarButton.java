package src;

import javax.swing.*;
import java.awt.*;

public class SidebarButton extends JToggleButton {
    public SidebarButton(String text) {
        super(text);
        setFocusPainted(false);
        setBorderPainted(false);
        setBackground(new Color(245, 245, 245));
        setForeground(Color.BLACK);
        setFont(new Font("Segoe UI", Font.PLAIN, 14));
        setCursor(new Cursor(Cursor.HAND_CURSOR));
        setHorizontalAlignment(SwingConstants.LEFT);
        setPreferredSize(new Dimension(180, 40));
        setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 10));
    }

    @Override
    protected void paintComponent(Graphics g) {
        if (isSelected()) {
            setBackground(new Color(30, 20, 255));
            setForeground(Color.WHITE);
        } else {
            setBackground(new Color(245, 245, 245));
            setForeground(Color.BLACK);
        }
        super.paintComponent(g);
    }
}
