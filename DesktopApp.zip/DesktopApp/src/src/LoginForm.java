package src;


import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

public class LoginForm extends JFrame {
    JTextField usernameField;
    JPasswordField passwordField;
    JButton loginBtn, goToSignupBtn;

    public LoginForm() {
        setTitle("Login Form");
        setSize(700, 400);
        setLayout(null);

        usernameField = new JTextField();
        passwordField = new JPasswordField();
        loginBtn = new JButton("Login");
        goToSignupBtn = new JButton("Signup");

        add(new JLabel("Username:")).setBounds(60, 30, 100, 25); add(usernameField).setBounds(130, 30, 150, 25);
        add(new JLabel("Password:")).setBounds(60, 70, 100, 25); add(passwordField).setBounds(130, 70, 150, 25);
        add(loginBtn).setBounds(130, 110, 150, 50);
        add(goToSignupBtn).setBounds(130, 200, 150, 50);

        loginBtn.addActionListener(e -> loginUser());
        goToSignupBtn.addActionListener(e -> {
            dispose();
            new SignupForm();
        });

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    
    void loginUser() {
    try {
        Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/oop", "root", "");
        String sql = "SELECT * FROM users WHERE username=? AND password=?";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, usernameField.getText());
        stmt.setString(2, new String(passwordField.getPassword()));
        ResultSet rs = stmt.executeQuery();

        if (rs.next()) {
            String fname = rs.getString("fname");
            String lname = rs.getString("lname");
            String role = rs.getString("role");

            JOptionPane.showMessageDialog(this, "Welcome " + fname + " " + lname + "!");

            // Open dashboard based on role
            if (role.equalsIgnoreCase("Admin")) {
                new AdminDashboard(fname).setVisible(true);
            } else if (role.equalsIgnoreCase("User")) {
                new UserDashboard(fname).setVisible(true);
            }

            dispose(); // close the login window

        } else {
            JOptionPane.showMessageDialog(this, "Invalid username or password.");
        }

        conn.close();
    } catch (Exception ex) {
        JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
    }
}

    

    public static void main(String[] args) {
        
        new LoginForm();
        try {
            UIManager.setLookAndFeel(new com.formdev.flatlaf.FlatLightLaf());
        } catch (Exception ex) {
            System.err.println("Failed to initialize LaF");
        }

        
        
    }
}