package src;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import views.*;

public class AdminDashboard extends JFrame {
    private JPanel sidebar, contentPanel;
    private CardLayout cardLayout;

    public AdminDashboard(String fname) {
        setTitle("Admin Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 550);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Sidebar Panel
        sidebar = new JPanel();
        sidebar.setPreferredSize(new Dimension(200, getHeight()));
        sidebar.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 10));
        sidebar.setBackground(new Color(245, 245, 245));

        // Toggle buttons
        ButtonGroup group = new ButtonGroup();

        SidebarButton btnDashboard = new SidebarButton("Dashboard");
        SidebarButton btnUsers = new SidebarButton("Users");
        SidebarButton btnBookings = new SidebarButton("Bookings");
        SidebarButton btnSettings = new SidebarButton("Settings");
        SidebarButton btnLogout = new SidebarButton("Logout");

        group.add(btnDashboard);
        group.add(btnUsers);
        group.add(btnBookings);
        group.add(btnSettings);
        group.add(btnLogout);

        sidebar.add(btnDashboard);
        sidebar.add(btnUsers);
        sidebar.add(btnBookings);
        sidebar.add(btnSettings);
        sidebar.add(btnLogout);

        // Content Panel
        cardLayout = new CardLayout();
        contentPanel = new JPanel(cardLayout);

        contentPanel.add(new DashboardView("Admin"), "dashboard");
        contentPanel.add(new UsersView(), "users");
        contentPanel.add(new SettingsView(), "settings");

        // Toggle Actions
        btnDashboard.addActionListener(e -> {
            cardLayout.show(contentPanel, "dashboard");
            btnDashboard.setSelected(true);
        });

        btnUsers.addActionListener(e -> {
            cardLayout.show(contentPanel, "users");
            btnUsers.setSelected(true);
        });

        btnSettings.addActionListener(e -> {
            cardLayout.show(contentPanel, "settings");
            btnSettings.setSelected(true);
        });

        btnLogout.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to logout?", "Logout", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                dispose();
                new LoginForm();
            } else {
                btnDashboard.setSelected(true); // go back to dashboard
            }
        });

        // Set default selected
        btnDashboard.setSelected(true);
        cardLayout.show(contentPanel, "dashboard");

        add(sidebar, BorderLayout.WEST);
        add(contentPanel, BorderLayout.CENTER);
        setVisible(true);
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(new com.formdev.flatlaf.FlatLightLaf());
        } catch (Exception ex) {
            System.err.println("Failed to initialize LaF");
        }

        SwingUtilities.invokeLater(() -> new AdminDashboard("Rodel"));
    }
}
