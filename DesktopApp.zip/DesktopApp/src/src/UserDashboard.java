package src;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import views.*;

public class UserDashboard extends JFrame {
    private JPanel sidebar, contentPanel;
    private CardLayout cardLayout;

    public UserDashboard(String fname) {
        setTitle("User Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 500);
        setLocationRelativeTo(null);

        sidebar = new JPanel(new GridLayout(0, 1, 5, 5));
        sidebar.setPreferredSize(new Dimension(200, getHeight()));
        sidebar.setBackground(new Color(60, 63, 65));

        JLabel welcomeLabel = new JLabel("Hello, User " + fname);
        welcomeLabel.setForeground(Color.WHITE);
        welcomeLabel.setHorizontalAlignment(SwingConstants.CENTER);
        sidebar.add(welcomeLabel);

        JButton dashboardBtn = new JButton("Dashboard");
        JButton settingsBtn = new JButton("Settings");
        JButton logoutBtn = new JButton("Logout");

        sidebar.add(dashboardBtn);
        sidebar.add(settingsBtn);
        sidebar.add(logoutBtn);

        contentPanel = new JPanel();
        cardLayout = new CardLayout();
        contentPanel.setLayout(cardLayout);

        contentPanel.add(new DashboardView("User"), "dashboard");
        contentPanel.add(new SettingsView(), "settings");

        dashboardBtn.addActionListener(e -> cardLayout.show(contentPanel, "dashboard"));
        settingsBtn.addActionListener(e -> cardLayout.show(contentPanel, "settings"));
        logoutBtn.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to logout?", "Logout", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                dispose();
                new LoginForm();
            }
        });

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(sidebar, BorderLayout.WEST);
        getContentPane().add(contentPanel, BorderLayout.CENTER);

        setVisible(true);
    }
}
